﻿namespace lab2_GUI_remake_
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.path_txt = new System.Windows.Forms.TextBox();
            this.browse_btn = new System.Windows.Forms.Button();
            this.back_btn = new System.Windows.Forms.Button();
            this.listviewfile = new System.Windows.Forms.ListView();
            this.exit_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "Path";
            // 
            // path_txt
            // 
            this.path_txt.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.path_txt.Location = new System.Drawing.Point(84, 46);
            this.path_txt.Name = "path_txt";
            this.path_txt.Size = new System.Drawing.Size(481, 38);
            this.path_txt.TabIndex = 1;
            this.path_txt.TextChanged += new System.EventHandler(this.path_txt_TextChanged);
            this.path_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.path_txt_KeyPress);
            // 
            // browse_btn
            // 
            this.browse_btn.Location = new System.Drawing.Point(571, 46);
            this.browse_btn.Name = "browse_btn";
            this.browse_btn.Size = new System.Drawing.Size(162, 38);
            this.browse_btn.TabIndex = 2;
            this.browse_btn.Text = "Browse";
            this.browse_btn.UseVisualStyleBackColor = true;
            this.browse_btn.Click += new System.EventHandler(this.browse_btn_Click);
            // 
            // back_btn
            // 
            this.back_btn.Location = new System.Drawing.Point(739, 46);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(162, 38);
            this.back_btn.TabIndex = 3;
            this.back_btn.Text = "Back";
            this.back_btn.UseVisualStyleBackColor = true;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // listviewfile
            // 
            this.listviewfile.HideSelection = false;
            this.listviewfile.Location = new System.Drawing.Point(31, 118);
            this.listviewfile.Name = "listviewfile";
            this.listviewfile.Size = new System.Drawing.Size(867, 386);
            this.listviewfile.TabIndex = 4;
            this.listviewfile.UseCompatibleStateImageBehavior = false;
            // 
            // exit_btn
            // 
            this.exit_btn.Location = new System.Drawing.Point(328, 510);
            this.exit_btn.Name = "exit_btn";
            this.exit_btn.Size = new System.Drawing.Size(260, 51);
            this.exit_btn.TabIndex = 5;
            this.exit_btn.Text = "Exit";
            this.exit_btn.UseVisualStyleBackColor = true;
            this.exit_btn.Click += new System.EventHandler(this.exit_btn_Click);
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(945, 573);
            this.Controls.Add(this.exit_btn);
            this.Controls.Add(this.listviewfile);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.browse_btn);
            this.Controls.Add(this.path_txt);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form6";
            this.Text = "File explorer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox path_txt;
        private System.Windows.Forms.Button browse_btn;
        private System.Windows.Forms.Button back_btn;
        private System.Windows.Forms.ListView listviewfile;
        private System.Windows.Forms.Button exit_btn;
    }
}