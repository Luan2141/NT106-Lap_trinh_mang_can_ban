﻿namespace lab2_GUI_remake_
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exit_btn = new System.Windows.Forms.Button();
            this.number_cha = new System.Windows.Forms.TextBox();
            this.number_word = new System.Windows.Forms.TextBox();
            this.number_line = new System.Windows.Forms.TextBox();
            this.url_text = new System.Windows.Forms.TextBox();
            this.namefile_text = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.content_text = new System.Windows.Forms.RichTextBox();
            this.read_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // exit_btn
            // 
            this.exit_btn.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_btn.Location = new System.Drawing.Point(297, 34);
            this.exit_btn.Name = "exit_btn";
            this.exit_btn.Size = new System.Drawing.Size(193, 52);
            this.exit_btn.TabIndex = 25;
            this.exit_btn.Text = "THOÁT";
            this.exit_btn.UseVisualStyleBackColor = true;
            this.exit_btn.Click += new System.EventHandler(this.exit_btn_Click);
            // 
            // number_cha
            // 
            this.number_cha.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.number_cha.Location = new System.Drawing.Point(211, 382);
            this.number_cha.Name = "number_cha";
            this.number_cha.Size = new System.Drawing.Size(297, 34);
            this.number_cha.TabIndex = 24;
            // 
            // number_word
            // 
            this.number_word.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.number_word.Location = new System.Drawing.Point(211, 317);
            this.number_word.Name = "number_word";
            this.number_word.Size = new System.Drawing.Size(297, 34);
            this.number_word.TabIndex = 23;
            // 
            // number_line
            // 
            this.number_line.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.number_line.Location = new System.Drawing.Point(211, 246);
            this.number_line.Name = "number_line";
            this.number_line.Size = new System.Drawing.Size(297, 34);
            this.number_line.TabIndex = 22;
            // 
            // url_text
            // 
            this.url_text.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.url_text.Location = new System.Drawing.Point(211, 187);
            this.url_text.Name = "url_text";
            this.url_text.Size = new System.Drawing.Size(297, 34);
            this.url_text.TabIndex = 21;
            // 
            // namefile_text
            // 
            this.namefile_text.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.namefile_text.Location = new System.Drawing.Point(211, 121);
            this.namefile_text.Name = "namefile_text";
            this.namefile_text.Size = new System.Drawing.Size(297, 34);
            this.namefile_text.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(26, 387);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(138, 29);
            this.label5.TabIndex = 19;
            this.label5.Text = "Số kí tự";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(26, 317);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 29);
            this.label4.TabIndex = 18;
            this.label4.Text = "Số từ";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(26, 251);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 29);
            this.label3.TabIndex = 17;
            this.label3.Text = "Số dòng";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 187);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 29);
            this.label2.TabIndex = 16;
            this.label2.Text = "Url";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(26, 124);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 31);
            this.label1.TabIndex = 15;
            this.label1.Text = "Tên file";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // content_text
            // 
            this.content_text.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.content_text.Location = new System.Drawing.Point(534, 53);
            this.content_text.Name = "content_text";
            this.content_text.Size = new System.Drawing.Size(372, 363);
            this.content_text.TabIndex = 14;
            this.content_text.Text = "";
            // 
            // read_btn
            // 
            this.read_btn.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.read_btn.Location = new System.Drawing.Point(31, 34);
            this.read_btn.Name = "read_btn";
            this.read_btn.Size = new System.Drawing.Size(193, 52);
            this.read_btn.TabIndex = 13;
            this.read_btn.Text = "ĐỌC FILE";
            this.read_btn.UseVisualStyleBackColor = true;
            this.read_btn.Click += new System.EventHandler(this.read_btn_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(931, 452);
            this.Controls.Add(this.exit_btn);
            this.Controls.Add(this.number_cha);
            this.Controls.Add(this.number_word);
            this.Controls.Add(this.number_line);
            this.Controls.Add(this.url_text);
            this.Controls.Add(this.namefile_text);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.content_text);
            this.Controls.Add(this.read_btn);
            this.Name = "Form3";
            this.Text = "info file";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exit_btn;
        private System.Windows.Forms.TextBox number_cha;
        private System.Windows.Forms.TextBox number_word;
        private System.Windows.Forms.TextBox number_line;
        private System.Windows.Forms.TextBox url_text;
        private System.Windows.Forms.TextBox namefile_text;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox content_text;
        private System.Windows.Forms.Button read_btn;
    }
}