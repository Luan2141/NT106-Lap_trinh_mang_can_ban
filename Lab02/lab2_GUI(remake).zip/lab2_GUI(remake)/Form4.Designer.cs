﻿namespace lab2_GUI_remake_
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exit_btn = new System.Windows.Forms.Button();
            this.output_text = new System.Windows.Forms.RichTextBox();
            this.input_text = new System.Windows.Forms.RichTextBox();
            this.save_btn = new System.Windows.Forms.Button();
            this.caculate_btn = new System.Windows.Forms.Button();
            this.read_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // exit_btn
            // 
            this.exit_btn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.exit_btn.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_btn.Location = new System.Drawing.Point(223, 373);
            this.exit_btn.Name = "exit_btn";
            this.exit_btn.Size = new System.Drawing.Size(346, 52);
            this.exit_btn.TabIndex = 11;
            this.exit_btn.Text = "Thoát";
            this.exit_btn.UseVisualStyleBackColor = false;
            this.exit_btn.Click += new System.EventHandler(this.exit_btn_Click);
            // 
            // output_text
            // 
            this.output_text.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.output_text.Location = new System.Drawing.Point(421, 93);
            this.output_text.Name = "output_text";
            this.output_text.Size = new System.Drawing.Size(324, 268);
            this.output_text.TabIndex = 10;
            this.output_text.Text = "";
            // 
            // input_text
            // 
            this.input_text.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.input_text.Location = new System.Drawing.Point(56, 93);
            this.input_text.Name = "input_text";
            this.input_text.Size = new System.Drawing.Size(324, 268);
            this.input_text.TabIndex = 9;
            this.input_text.Text = "";
            // 
            // save_btn
            // 
            this.save_btn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.save_btn.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.save_btn.Location = new System.Drawing.Point(577, 25);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(168, 52);
            this.save_btn.TabIndex = 8;
            this.save_btn.Text = "Ghi";
            this.save_btn.UseVisualStyleBackColor = false;
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // caculate_btn
            // 
            this.caculate_btn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.caculate_btn.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.caculate_btn.Location = new System.Drawing.Point(319, 25);
            this.caculate_btn.Name = "caculate_btn";
            this.caculate_btn.Size = new System.Drawing.Size(168, 52);
            this.caculate_btn.TabIndex = 7;
            this.caculate_btn.Text = "Tính";
            this.caculate_btn.UseVisualStyleBackColor = false;
            this.caculate_btn.Click += new System.EventHandler(this.caculate_btn_Click);
            // 
            // read_btn
            // 
            this.read_btn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.read_btn.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.read_btn.Location = new System.Drawing.Point(56, 25);
            this.read_btn.Name = "read_btn";
            this.read_btn.Size = new System.Drawing.Size(168, 52);
            this.read_btn.TabIndex = 6;
            this.read_btn.Text = "Đọc";
            this.read_btn.UseVisualStyleBackColor = false;
            this.read_btn.Click += new System.EventHandler(this.read_btn_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exit_btn);
            this.Controls.Add(this.output_text);
            this.Controls.Add(this.input_text);
            this.Controls.Add(this.save_btn);
            this.Controls.Add(this.caculate_btn);
            this.Controls.Add(this.read_btn);
            this.Name = "Form4";
            this.Text = "Caculator";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button exit_btn;
        private System.Windows.Forms.RichTextBox output_text;
        private System.Windows.Forms.RichTextBox input_text;
        private System.Windows.Forms.Button save_btn;
        private System.Windows.Forms.Button caculate_btn;
        private System.Windows.Forms.Button read_btn;
    }
}