﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using org.matheval;

namespace lab2_GUI_remake_
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void exit_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void read_btn_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            if (ofd.ShowDialog() != DialogResult.OK)
            {
                MessageBox.Show("Invalid path");
            }
            else
            {
                StreamReader sr = new StreamReader(ofd.FileName);
                string content = sr.ReadToEnd();
                input_text.Text = content;
                sr.Close();
            }
        }

        private void caculate_btn_Click(object sender, EventArgs e)
        {
            output_text.Clear();
            string input_txt = input_text.Text;
            string[] element = input_txt.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string s in element)
            {
                try
                {

                    Expression expression = new Expression(s);
                    string check = expression.Eval().ToString();
                    if (check == "True" || check == "False")
                    {
                        output_text.Text += s + " : " + check + "\n";
                    }
                    else
                    {
                        output_text.Text += s + " = " + check + "\n";
                    }
                }
                catch (Exception)
                {
                    output_text.Text += s + " : Math error\n";
                }
            }

        }

        private void save_btn_Click(object sender, EventArgs e)
        {
            string content_save = output_text.Text;
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "Text (*.txt)|*.txt";

            if (save.ShowDialog() != DialogResult.OK)
            {
                MessageBox.Show("Invalid path");
            }
            else
            {
                StreamWriter sr = new StreamWriter(save.FileName, false);
                sr.WriteLine(content_save);
                sr.Close();
            }
        }
    }
}
