﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab2_GUI_remake_
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void read_btn_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            if (ofd.ShowDialog() != DialogResult.OK)
            {
                MessageBox.Show("Invalid Path");
            }
            else
            {
                StreamReader streamReader = new StreamReader(ofd.FileName);
                string content = streamReader.ReadToEnd();
                streamReader.Close();
                content_text.Text = content;
                namefile_text.Text = Path.GetFileName(ofd.FileName);
                url_text.Text = ofd.FileName.ToString();
                string[] line = content_text.Text.Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries);
                number_line.Text = line.Count().ToString();
                string[] word = content_text.Text.Split(new string[] { "\n", " " }, StringSplitOptions.RemoveEmptyEntries);
                number_word.Text = word.Count().ToString();
                number_cha.Text = (content.Length).ToString();
            }
        }

        private void exit_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}
