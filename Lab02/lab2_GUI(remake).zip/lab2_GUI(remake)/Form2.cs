﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab2_GUI_remake_
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void exit_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void read_btn_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() != DialogResult.OK)
            {
                MessageBox.Show("Invalid path");
            }
            else
            {
                StreamReader sr = new StreamReader(ofd.FileName);
                string content_read = sr.ReadToEnd();
                content_txt.Text = content_read;
                sr.Close();
            }
        }

        private void save_btn_Click(object sender, EventArgs e)
        {
            string content_save = content_txt.Text;
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "Text (*.txt)|*.txt";
            if (save.ShowDialog() != DialogResult.OK)
            {
                MessageBox.Show("Invalid path");
            }
            else
            {
                StreamWriter sr = new StreamWriter(save.FileName, false);
                sr.WriteLine(content_save.ToUpper());
                sr.Close();
            }
        }
    }
}
