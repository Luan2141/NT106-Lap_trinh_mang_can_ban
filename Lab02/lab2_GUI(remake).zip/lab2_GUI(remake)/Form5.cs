﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClosedXML.Excel;

namespace lab2_GUI_remake_
{
    public partial class Form5 : Form
    {
        
        public Form5()
        {
            InitializeComponent();
           
        }
        private void read_btn_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();
            form7.ShowDialog();
            
        }
        private void save_btn_Click(object sender, EventArgs e)
        {
            string excell_path = "";
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "Excel Files(*.xlsx) | *.xlsx";
            if (save.ShowDialog() != DialogResult.OK)
            {
                MessageBox.Show("Chọn file excell để lưu");
            }
            else
            {   
                excell_path=save.FileName;
                string file_path = "D:\\input.txt";
                if (!File.Exists(file_path))
                {
                   OpenFileDialog open = new OpenFileDialog();
                   if(open.ShowDialog() != DialogResult.OK || open.FileName.Last().ToString()!= "input.txt")
                    {
                        MessageBox.Show("Chọn file input.txt");
                    }
                    else
                    {
                        file_path = open.FileName;
                    }
                   

                }
                var workbook = new XLWorkbook(excell_path);

                var worksheet = workbook.Worksheet("Sheet1");
                worksheet.Cell("A1").Value = "MSSV";
                worksheet.Cell("B1").Value = "Họ tên";
                worksheet.Cell("C1").Value = "SDT";
                worksheet.Cell("D1").Value = "Điểm toán";
                worksheet.Cell("E1").Value = "Điểm văn";
                worksheet.Cell("F1").Value = "Điểm trung bình";

                // Điều chỉnh định dạng cho cột
                worksheet.Column("A").Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                worksheet.Column("B").Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                worksheet.Column("C").Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                worksheet.Column("D").Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                worksheet.Column("E").Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                worksheet.Column("F").Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                int row = 2;
                foreach (string line in File.ReadLines(file_path))
                {
                    string[] data = line.Split(';');
                    for (int i = 0; i < data.Length; i++)
                    {
                        worksheet.Cell(row, i + 1).SetValue(data[i].ToString());
                       
                    }

                   
                    double mathScore = double.Parse(data[3]);
                    double litScore = double.Parse(data[4]);
                    double avgScore = Math.Round((mathScore + litScore) / 2,2);

                    
                    worksheet.Cell(row, 6).SetValue(avgScore.ToString());
                    
                    row++;
                }
                workbook.SaveAs(excell_path);

            }
        }

        private void exit_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void display_btn_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Excel Files|*.xls;*.xlsx;*.xlsm";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string file_path = openFileDialog.FileName;
                DataTable data = new DataTable();
                using (var workbook = new XLWorkbook(file_path))
                {
                    
                    var worksheet = workbook.Worksheet(1);

                    
                    foreach (var row in worksheet.RowsUsed())
                    {
                        

                        if (data.Columns.Count == 0)
                        {
                            
                            foreach (var cell in row.CellsUsed())
                            {
                                data.Columns.Add(cell.Value.ToString());
                            }
                        }
                        else
                        {
                            
                            DataRow dataRow = data.NewRow();
                            for (int i = 0; i < row.Cells().Count(); i++)
                            {
                                dataRow[i] = row.Cell(i + 1).Value.ToString();
                            }
                            data.Rows.Add(dataRow);
                        }
                    }

                }
                dataGridView1.DataSource = data;
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                
            }
            else
            {
                MessageBox.Show("Hãy chọn file excell");
            }
        }
    }
}
