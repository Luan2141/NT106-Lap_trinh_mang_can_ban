﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab2_GUI_remake_
{
    public partial class Form7 : Form
    {
       
       
        public Form7()
        {
            InitializeComponent();
            
        }
      
       
        private bool check_name (string name)
        {
            return Regex.IsMatch(name, @"^[\p{L}\s]+$");
        }
        private bool check_score (string score_str)
        {
            double score;
           if (double.TryParse(score_str, out score)&& (score >=0 && score <=10) )
            {
                return true;
            }
           return false;
        }
        private bool check_id (string id)
        {
            return Regex.IsMatch(id, @"^\d{8}$");
        }
        private bool check_phone (string phone)
        {
            return Regex.IsMatch(phone, @"^\d{10}$");
        }

        private void save_btn_Click(object sender, EventArgs e)
        {
            string current_path = "D:\\";
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "Browse for folder has input.txt";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                current_path = dialog.SelectedPath;
                
            }
            else
            {
                MessageBox.Show("Dùng thư mục D để lưu");
            }
            
            string file_path = Path.Combine(current_path, "input.txt");
            if (check_id(id_txt.Text) && check_name(name_txt.Text) && check_phone(phone_txt.Text) && check_score(math_score.Text) && check_score(lit_score.Text))
            {
                try
                {
                    
                    if (File.Exists(file_path))
                    {
                        
                        using (StreamWriter streamWriter = new StreamWriter(file_path, append: true))
                        {
                            streamWriter.WriteLine(id_txt.Text + ";" + name_txt.Text + ";" + phone_txt.Text + ";" + math_score.Text + ";" + lit_score.Text);
                        }
                    }
                    else
                    {
                        
                        using (StreamWriter writer = File.CreateText(file_path))
                        {
                            writer.WriteLine(id_txt.Text + ";" + name_txt.Text + ";" + phone_txt.Text + ";" + math_score.Text + ";" + lit_score.Text);
                        }
                    }
                    MessageBox.Show("Nhập thành công");
                    this.Close();
                  
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Đã xảy ra lỗi: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Thông tin không hợp lệ");
            }
        }

    }
}
