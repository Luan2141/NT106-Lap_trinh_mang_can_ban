﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab2_GUI_remake_
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
            listviewfile.View = View.Details;
            listviewfile.Columns.Add("Name", 400);
            listviewfile.Columns.Add("Date modified", 200);
            listviewfile.Columns.Add("Type", 100);
            listviewfile.Columns.Add("Size", 200);

                
            ImageList icon_image = new ImageList();
            icon_image.Images.Add(Properties.Resources.file);
            icon_image.Images.Add(Properties.Resources.folder);
            listviewfile.SmallImageList = icon_image;
            string ini_path = "C:" +"\\" ;
            path_txt.Text = ini_path;
            display(path_txt.Text);
            
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            DirectoryInfo parentDirectory = Directory.GetParent(path_txt.Text);

            if (parentDirectory != null)
            {
                path_txt.Text = parentDirectory.FullName;
                display(path_txt.Text);
            }
        }
        private string convert_size(long size_file)
        {
            string result = "";
            string[] unit = { "B","KB","MB","GB"};
            int index = 0;
            double size = size_file;
            while (size >= 1024 && index <= unit.Length -1)
            {
                size /= 1024;
                index++;
            }
            size = Math.Round(size, 3);
            result = size.ToString() +" "+ unit[index];


            return result;
        }
        private void display_file(DirectoryInfo dir)
        {
            foreach (var file in dir.GetFiles())
            {
               ListViewItem item = new ListViewItem(file.Name,0);
               FileInfo info = new FileInfo(file.FullName);
                
                item.SubItems.Add(info.LastWriteTime.ToString());
                item.SubItems.Add((info.Extension).Replace(".", "")) ;
                item.SubItems.Add(convert_size(info.Length));
                listviewfile.Items.Add(item);

                
            }
        }
        private void display_folder(DirectoryInfo dir)
        {
            foreach (var folder in dir.GetDirectories())
            {
                ListViewItem item = new ListViewItem(folder.Name, 1);
                item.SubItems.Add(folder.LastWriteTime.ToString());
                item.SubItems.Add("File folder");
                item.SubItems.Add("");
                listviewfile.Items.Add(item);

            }
        }
        private void display (string path)
        {   
            
           
            try
            {
                listviewfile.Items.Clear();
                DirectoryInfo dir = new DirectoryInfo(path);
                display_file(dir);
                display_folder(dir);
            }
            catch (Exception ) {
                MessageBox.Show("Folder not exist in this path");
            }
        }
        private void browse_btn_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "Browse for folder";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                path_txt.Text = dialog.SelectedPath;
                display(path_txt.Text);
            }
            else
            {
                MessageBox.Show("Chose a folder");
            }
            

        }

        private void exit_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
       
        private void path_txt_TextChanged(object sender, EventArgs e)

        {
          

        }

        private void path_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                display(path_txt.Text);
            }
           
        }
    }
}
